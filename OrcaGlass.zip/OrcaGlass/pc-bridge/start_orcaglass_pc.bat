@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 orcaglass_pc.py
) else (
    python orcaglass_pc.py
)
echo.
echo OrcaGlass PC Link est arrêté.
pause
