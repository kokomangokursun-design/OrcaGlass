#!/usr/bin/env python3
"""OrcaGlass PC Link: reçoit un modèle depuis Android et l'ouvre dans OrcaSlicer.

Dépendances: Python 3.9+ uniquement (bibliothèque standard).
À utiliser uniquement sur ton réseau local de confiance.
"""
from __future__ import annotations

import hmac
import json
import os
import secrets
import socket
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

APP_DIR = Path(__file__).resolve().parent
CONFIG_PATH = APP_DIR / "orcaglass_pc_config.json"
INBOX = Path.home() / "OrcaGlass" / "Inbox"
OUTBOX = Path.home() / "OrcaGlass" / "Outbox"
MAX_UPLOAD = 300 * 1024 * 1024
ALLOWED_EXTENSIONS = {".3mf", ".stl", ".obj"}


def load_config() -> dict:
    if CONFIG_PATH.exists():
        try:
            config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise SystemExit(f"Configuration invalide: {exc}")
    else:
        config = {
            "token": secrets.token_urlsafe(24),
            "orcaslicer_exe": "",
        }
        CONFIG_PATH.write_text(json.dumps(config, indent=2), encoding="utf-8")
    token = str(config.get("token", "")).strip()
    if len(token) < 20:
        token = secrets.token_urlsafe(24)
        config["token"] = token
        CONFIG_PATH.write_text(json.dumps(config, indent=2), encoding="utf-8")
    return config


CONFIG = load_config()
TOKEN = str(CONFIG["token"])
# Tolère l'ancien nom mal orthographié pour ne pas perdre une config déjà créée.
SLICER_PATH = str(CONFIG.get("orcaslicer_exe", "")).strip()


def local_ipv4_addresses() -> list[str]:
    addresses: set[str] = set()
    try:
        for item in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = item[4][0]
            if not ip.startswith("127."):
                addresses.add(ip)
    except OSError:
        pass
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.connect(("192.0.2.1", 80))
            ip = sock.getsockname()[0]
            if not ip.startswith("127."):
                addresses.add(ip)
        finally:
            sock.close()
    except OSError:
        pass
    return sorted(addresses)


def send_json(handler: BaseHTTPRequestHandler, status: int, payload: dict) -> None:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()
    handler.wfile.write(body)


class Handler(BaseHTTPRequestHandler):
    server_version = "OrcaGlassPC/0.1"

    def log_message(self, fmt: str, *args) -> None:
        print("[OrcaGlass] " + (fmt % args))

    def authorized(self) -> bool:
        supplied = self.headers.get("X-OrcaGlass-Token", "")
        return bool(supplied) and hmac.compare_digest(supplied, TOKEN)

    def do_GET(self) -> None:
        if not self.authorized():
            send_json(self, 401, {"ok": False, "error": "Jeton invalide"})
            return
        parsed = urlparse(self.path)
        if parsed.path == "/health":
            send_json(self, 200, {"ok": True, "service": "OrcaGlass PC Link", "version": "0.1.0"})
            return
        if parsed.path == "/gcode-files":
            OUTBOX.mkdir(parents=True, exist_ok=True)
            files = []
            for item in sorted(OUTBOX.iterdir(), key=lambda f: f.stat().st_mtime, reverse=True):
                if item.is_file() and item.suffix.lower() in {".gcode", ".gco", ".gc"}:
                    stat = item.stat()
                    files.append({"name": item.name, "size": stat.st_size, "modified": int(stat.st_mtime)})
            send_json(self, 200, {"ok": True, "files": files[:100]})
            return
        if parsed.path == "/gcode-file":
            name = parse_qs(parsed.query).get("name", [""])[0]
            safe_name = Path(name.replace("\\", "/")).name
            target = OUTBOX / safe_name
            if not safe_name or target.resolve().parent != OUTBOX.resolve() or target.suffix.lower() not in {".gcode", ".gco", ".gc"} or not target.is_file():
                send_json(self, 404, {"ok": False, "error": "G-code introuvable dans Outbox"})
                return
            size = target.stat().st_size
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(size))
            self.send_header("Content-Disposition", f'attachment; filename="{safe_name}"')
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            with target.open("rb") as stream:
                while True:
                    chunk = stream.read(1024 * 1024)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
            return
        send_json(self, 404, {"ok": False, "error": "Route inconnue"})

    def do_PUT(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path != "/open-model":
            send_json(self, 404, {"ok": False, "error": "Route inconnue"})
            return
        if not self.authorized():
            send_json(self, 401, {"ok": False, "error": "Jeton invalide"})
            return

        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            send_json(self, 411, {"ok": False, "error": "Content-Length manquant"})
            return
        if content_length < 1 or content_length > MAX_UPLOAD:
            send_json(self, 413, {"ok": False, "error": "Fichier vide ou supérieur à 300 Mo"})
            return

        query = parse_qs(parsed.query)
        requested_name = query.get("name", [""])[0]
        # Ne garde que le nom de fichier, jamais un chemin fourni par le mobile.
        safe_name = Path(requested_name.replace("\\", "/")).name
        extension = Path(safe_name).suffix.lower()
        if extension not in ALLOWED_EXTENSIONS:
            send_json(self, 415, {"ok": False, "error": "Formats acceptés : 3MF, STL, OBJ"})
            return
        if not safe_name or safe_name in {".", ".."}:
            send_json(self, 400, {"ok": False, "error": "Nom de fichier invalide"})
            return

        INBOX.mkdir(parents=True, exist_ok=True)
        destination = INBOX / safe_name
        if destination.exists():
            stem = destination.stem
            suffix = destination.suffix
            counter = 2
            while destination.exists():
                destination = INBOX / f"{stem}_{counter}{suffix}"
                counter += 1

        remaining = content_length
        try:
            with destination.open("xb") as target:
                while remaining:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise ConnectionError("Transfert interrompu")
                    target.write(chunk)
                    remaining -= len(chunk)
        except Exception as exc:
            try:
                destination.unlink(missing_ok=True)
            except OSError:
                pass
            send_json(self, 400, {"ok": False, "error": f"Transfert incomplet : {exc}"})
            return

        opened = False
        open_error = ""
        try:
            if SLICER_PATH:
                slicer = Path(os.path.expandvars(SLICER_PATH)).expanduser()
                if not slicer.is_file():
                    raise FileNotFoundError(f"OrcaSlicer introuvable : {slicer}")
                import subprocess
                subprocess.Popen([str(slicer), str(destination)], close_fds=True)
                opened = True
            elif os.name == "nt":
                os.startfile(str(destination))  # type: ignore[attr-defined]
                opened = True
            else:
                open_error = "Fichier enregistré; associe OrcaSlicer à ce type de fichier ou renseigne orcaslicer_exe."
        except Exception as exc:
            open_error = str(exc)

        send_json(self, 201, {
            "ok": True,
            "saved": str(destination),
            "opened": opened,
            "message": "Modèle reçu et ouvert dans OrcaSlicer." if opened else "Modèle reçu, mais ouverture automatique non effectuée.",
            "detail": open_error,
        })


def main() -> None:
    INBOX.mkdir(parents=True, exist_ok=True)
    OUTBOX.mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer(("0.0.0.0", 8765), Handler)
    server.daemon_threads = True
    print("\n==============================================")
    print("          ORCAGLASS PC LINK  v0.1.0")
    print("==============================================")
    print("Relais actif sur le port 8765.")
    for ip in local_ipv4_addresses():
        print(f"Adresse à saisir dans Android : http://{ip}:8765")
    print(f"Jeton à saisir dans Android : {TOKEN}")
    print(f"Dossier de réception des modèles : {INBOX}")
    print(f"Dossier G-code à exporter depuis OrcaSlicer : {OUTBOX}")
    print("\nGarde cette fenêtre ouverte. Téléphone et PC sur le même Wi-Fi.")
    print("Ne redirige pas ce port vers Internet. Ctrl+C pour quitter.\n")
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        print("\nArrêt du relais OrcaGlass.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
