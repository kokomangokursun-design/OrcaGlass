# OrcaGlass — prototype Android + PC Link

**But :** piloter une Creality Ender 3 V2 depuis un téléphone Android, en laissant le PC gérer la liaison USB. L'application ne pilote pas le port série Android : elle parle à OctoPrint sur le réseau local.

## Fonctionnement

```text
MakerWorld (Android)
        │ télécharger 3MF / STL
        ▼ Wi-Fi local
OrcaGlass PC Link (Windows)
        │ ouvre le modèle
        ▼
OrcaSlicer (tranchage sur le PC)
        │ exporter le G-code dans %USERPROFILE%\OrcaGlass\Outbox
        ▼ Wi-Fi local
OrcaGlass Android ──Wi-Fi──> OctoPrint (sur le PC) ──USB──> Ender 3 V2
```

L'application Android permet déjà de :
- parcourir MakerWorld dans un onglet intégré ;
- télécharger les modèles MakerWorld ;
- transmettre un fichier 3MF/STL/OBJ au PC et demander son ouverture dans OrcaSlicer ;
- envoyer un G-code au dossier local d'OctoPrint ;
- lire les températures, l'état et la progression ;
- démarrer, mettre en pause/reprendre et annuler une impression.

Le relais PC expose aussi le dossier `%USERPROFILE%/OrcaGlass/Outbox` à l'application. Après avoir exporté le G-code depuis OrcaSlicer dans ce dossier, l'application peut le récupérer et l'envoyer à OctoPrint sans devoir transférer manuellement le G-code vers le téléphone.

## 1. Préparer le PC et l'Ender 3 V2

1. Installe OctoPrint sur Windows avec l'installateur Windows proposé depuis [OctoPrint.org](https://octoprint.org/download/).
2. Relie l'Ender 3 V2 au PC avec un **câble USB de données** (pas un câble charge uniquement). Allume l'imprimante.
3. Dans OctoPrint, choisis le port série COM de l'imprimante. Commence avec **115200 bauds** ; si ce débit ne fonctionne pas avec le firmware de ta carte, essaye 250000. Ne laisse pas OrcaSlicer et OctoPrint essayer de contrôler simultanément le même port USB.
4. Termine l'assistant de première configuration OctoPrint, puis vérifie que l'état de la machine devient `Operational`.
5. Dans OctoPrint, ouvre **Settings → API** et copie la clé API. Garde-la privée.
6. Relie le PC et le téléphone au même réseau Wi-Fi. Dans Windows, autorise OctoPrint et Python sur le réseau privé dans le pare-feu lorsque Windows le demande (ports OctoPrint 5000 et OrcaGlass PC Link 8765, à adapter à ta configuration).

> OctoPrint utilise le câble USB comme liaison série avec la carte de l'imprimante. Le téléphone communique uniquement avec OctoPrint sur le réseau local.

## 2. Démarrer le relais OrcaGlass sur Windows

- Installe Python 3.9 ou plus récent si nécessaire.
- Double-clique sur `pc-bridge/start_orcaglass_pc.bat`.
- Au premier lancement, le relais crée `pc-bridge/orcaglass_pc_config.json` et affiche son jeton ainsi que les adresses IP de ton PC.
- Copie une adresse de la forme `http://192.168.x.x:8765` et le jeton dans Réglages → Relais PC dans l'application Android.
- Facultatif : arrête le relais, ouvre `orcaglass_pc_config.json`, renseigne le chemin complet de `orca-slicer.exe` dans `orcaslicer_exe`, puis relance le relais. Exemple :

```json
{
  "token": "le-jeton-genere-au-premier-demarrage",
  "orcaslicer_exe": "C:\\Program Files\\OrcaSlicer\\orca-slicer.exe"
}
```

Le relais reçoit les modèles dans `%USERPROFILE%/OrcaGlass/Inbox`. Il les ouvre avec OrcaSlicer si le chemin est renseigné. Sinon, Windows essaie l'application associée au fichier.

## 3. Paramétrer l'application Android

Dans Réglages :

- **URL OctoPrint** : par exemple `http://192.168.1.20:5000` (remplace l'adresse par celle de ton PC et garde le port réellement configuré dans OctoPrint).
- **Clé API OctoPrint** : colle la clé obtenue dans OctoPrint.
- **URL relais PC** : l'adresse affichée par `start_orcaglass_pc.bat`, par exemple `http://192.168.1.20:8765`.
- **Jeton relais PC** : colle le jeton affiché dans la fenêtre Windows.

L'adresse du PC peut changer après un redémarrage de la box. Pour éviter de devoir la modifier dans l'application, réserve une adresse IP locale au PC dans les paramètres DHCP de ta box.

## 4. Imprimer un modèle MakerWorld

1. Ouvre l'onglet MakerWorld et télécharge le modèle voulu en 3MF ou STL.
2. Dans Atelier, choisis le fichier téléchargé et envoie-le à OrcaSlicer sur le PC.
3. Dans OrcaSlicer, vérifie le profil **Creality Ender 3 V2**, le filament, le plateau et les réglages. Tranche le modèle.
4. Exporte le G-code dans `%USERPROFILE%/OrcaGlass/Outbox`.
5. Dans Atelier, actualise la liste « G-code exportés sur le PC », puis touche **Envoyer** sur le fichier voulu. L'application le transfère vers OctoPrint et le sélectionne.
6. Dans Accueil, vérifie l'état, le fichier et les conditions de l'imprimante, puis appuie sur **Lancer l'impression** et confirme.

Tu peux aussi envoyer un G-code déjà présent sur ton téléphone depuis Atelier.

## 5. Compiler l'APK directement sur GitHub (sans Android Studio)

Le projet contient le workflow GitHub Actions `\.github/workflows/android.yml`. À chaque push sur `main`/`master`, GitHub installe Java 17, Gradle 8.9 et Android SDK 35, puis compile l'APK de débogage.

1. Décompresse `OrcaGlass_Source.zip` sur ton ordinateur.
2. Sur GitHub, crée un nouveau dépôt (par exemple `OrcaGlass`).
3. Envoie **le contenu du dossier `OrcaGlass`** dans le dépôt, à sa racine : `app/`, `pc-bridge/`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `README.md` et le dossier caché `.github/`. N'envoie pas seulement le fichier ZIP.
4. Ouvre l'onglet **Actions** du dépôt. Active les workflows si GitHub le demande.
5. Le workflow **Build OrcaGlass Android APK** démarre après l'envoi. Tu peux aussi le démarrer manuellement avec **Actions → Build OrcaGlass Android APK → Run workflow**.
6. Quand l'exécution devient verte, ouvre-la, descends à **Artifacts**, puis télécharge `OrcaGlass-debug-apk`.
7. Décompresse l'artefact : le fichier `app-debug.apk` est l'APK à installer sur ton téléphone Android.

Si l'onglet Actions ne montre aucun workflow, vérifie que le dossier `.github/workflows/` a bien été envoyé à la racine du dépôt. Sur Windows, active l'affichage des éléments masqués pour voir `.github`.

Cet APK est un build **debug** pour les tests, pas une version publiée sur le Play Store. Une signature de distribution pourra être ajoutée ultérieurement.

## 6. Construire localement (facultatif)

Tu peux aussi ouvrir le dossier `OrcaGlass` dans Android Studio, installer Android SDK Platform 35 si demandé, puis utiliser **Build → Build APK(s)**. L'APK debug sera créé dans `app/build/outputs/apk/debug/`.

## Limites de cette première version

- Le tranchage reste fait dans OrcaSlicer sur le PC : l'application Android ne prétend pas remplacer ce moteur.
- MakerWorld est affiché dans un navigateur intégré. Le site peut modifier son interface ou limiter certains téléchargements selon la session et ses propres règles.
- Il s'agit d'un prototype fonctionnel côté code, mais il n'a pas encore été validé sur ton modèle exact de téléphone, ton firmware Ender 3 V2 ou ton réseau.
- Le rafraîchissement de l'état est réglé à 2,5 secondes pour limiter le trafic. Une latence réseau nulle ne peut pas être garantie.
- Garde le PC éveillé et OctoPrint ouvert pendant toute l'impression. N'expose pas les ports OctoPrint ou OrcaGlass PC Link sur Internet. Surveille les premières impressions et ne laisse pas une imprimante chauffante fonctionner sans surveillance.
