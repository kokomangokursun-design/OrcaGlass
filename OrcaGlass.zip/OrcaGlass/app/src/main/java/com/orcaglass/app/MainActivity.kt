package com.orcaglass.app

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val Ink = Color(0xFF080B14)
private val Ink2 = Color(0xFF101827)
private val Glass = Color(0xB51B2638)
private val GlassLight = Color(0x1FFFFFFF)
private val Cyan = Color(0xFF74E4FF)
private val Blue = Color(0xFF6D8DFF)
private val Mint = Color(0xFF8EF0C8)
private val White = Color(0xFFF4F7FF)
private val Muted = Color(0xFF9AA8BE)
private val Danger = Color(0xFFFF7788)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.rgb(8, 11, 20)
        setContent { OrcaGlassApp() }
    }
}

private data class AppConfig(
    val octoUrl: String = "",
    val apiKey: String = "",
    val pcUrl: String = "",
    val pcToken: String = ""
)

private class ConfigStore(context: Context) {
    private val prefs = context.getSharedPreferences("orcaglass", Context.MODE_PRIVATE)
    fun read() = AppConfig(
        octoUrl = prefs.getString("octoUrl", "") ?: "",
        apiKey = prefs.getString("apiKey", "") ?: "",
        pcUrl = prefs.getString("pcUrl", "") ?: "",
        pcToken = prefs.getString("pcToken", "") ?: ""
    )
    fun write(config: AppConfig) {
        prefs.edit()
            .putString("octoUrl", config.octoUrl.trim().trimEnd('/'))
            .putString("apiKey", config.apiKey.trim())
            .putString("pcUrl", config.pcUrl.trim().trimEnd('/'))
            .putString("pcToken", config.pcToken.trim())
            .apply()
    }
}

private data class PrinterSnapshot(
    val connected: Boolean = false,
    val state: String = "Non connecté",
    val toolActual: Double? = null,
    val toolTarget: Double? = null,
    val bedActual: Double? = null,
    val bedTarget: Double? = null,
    val progress: Double? = null,
    val fileName: String = "Aucun fichier",
    val remainingSeconds: Int? = null,
    val error: String? = null
) {
    val printing: Boolean get() = state.equals("Printing", true) || progress != null && progress > 0.0 && progress < 100.0 && state != "Paused"
    val paused: Boolean get() = state.equals("Paused", true)
    val ready: Boolean get() = state.equals("Operational", true)
}

private object OctoPrintApi {
    private fun connection(config: AppConfig, path: String, method: String = "GET"): HttpURLConnection {
        require(config.octoUrl.startsWith("http://") || config.octoUrl.startsWith("https://")) {
            "Adresse OctoPrint invalide. Exemple : http://192.168.1.20:5000"
        }
        require(config.apiKey.isNotBlank()) { "Ajoute la clé API OctoPrint dans Réglages." }
        val c = (URL(config.octoUrl.trimEnd('/') + path).openConnection() as HttpURLConnection)
        c.requestMethod = method
        c.connectTimeout = 5000
        c.readTimeout = 9000
        c.setRequestProperty("X-Api-Key", config.apiKey)
        c.setRequestProperty("Accept", "application/json")
        return c
    }

    private fun readJson(config: AppConfig, path: String): JSONObject {
        val c = connection(config, path)
        return try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("OctoPrint HTTP $code : ${body.take(180)}")
            JSONObject(body)
        } finally { c.disconnect() }
    }

    fun snapshot(config: AppConfig): PrinterSnapshot {
        val printer = readJson(config, "/api/printer")
        val job = readJson(config, "/api/job")
        val stateObj = printer.optJSONObject("state")
        val state = stateObj?.optString("text", "Inconnu") ?: "Inconnu"
        val temp = printer.optJSONObject("temperature")
        val tool = temp?.optJSONObject("tool0")
        val bed = temp?.optJSONObject("bed")
        val progressObj = job.optJSONObject("progress")
        val file = job.optJSONObject("job")?.optJSONObject("file")
        return PrinterSnapshot(
            connected = true,
            state = state,
            toolActual = tool?.nullableDouble("actual"),
            toolTarget = tool?.nullableDouble("target"),
            bedActual = bed?.nullableDouble("actual"),
            bedTarget = bed?.nullableDouble("target"),
            progress = progressObj?.nullableDouble("completion"),
            fileName = file?.optString("name", "Aucun fichier") ?: "Aucun fichier",
            remainingSeconds = progressObj?.takeIf { it.has("printTimeLeft") && !it.isNull("printTimeLeft") }?.optInt("printTimeLeft")
        )
    }

    private fun JSONObject.nullableDouble(key: String): Double? {
        if (!has(key) || isNull(key)) return null
        val value = optDouble(key, Double.NaN)
        return value.takeIf { it.isFinite() }
    }

    fun command(config: AppConfig, body: JSONObject) {
        val c = connection(config, "/api/job", "POST")
        try {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code !in 200..299) {
                val detail = c.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                throw IllegalStateException("Commande refusée (HTTP $code). ${detail.take(160)}")
            }
        } finally { c.disconnect() }
    }

    fun uploadGcode(context: Context, config: AppConfig, uri: Uri): String {
        val name = displayName(context, uri)
        val temp = File.createTempFile("orcaglass_", ".upload", context.cacheDir)
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(temp).use { output -> input.copyTo(output) }
            } ?: throw IllegalStateException("Impossible de lire ce fichier.")
            return uploadGcodeFile(config, temp, name)
        } finally { temp.delete() }
    }

    fun uploadGcodeFile(config: AppConfig, file: File, originalName: String): String {
        val lower = originalName.lowercase(Locale.ROOT)
        require(lower.endsWith(".gcode") || lower.endsWith(".gco") || lower.endsWith(".gc")) {
            "Choisis un fichier G-code (.gcode ou .gco). Les STL/3MF doivent d'abord être tranchés dans OrcaSlicer."
        }
        require(file.length() in 1..400_000_000L) { "Fichier vide ou trop volumineux (limite : 400 Mo)." }
        val safeName = originalName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "print.gcode" }
        val boundary = "----OrcaGlass${System.nanoTime()}"
        val prefix = buildString {
            append("--$boundary\r\n")
            append("Content-Disposition: form-data; name=\"file\"; filename=\"$safeName\"\r\n")
            append("Content-Type: application/octet-stream\r\n\r\n")
        }.toByteArray(Charsets.UTF_8)
        val suffix = "\r\n--$boundary\r\nContent-Disposition: form-data; name=\"select\"\r\n\r\ntrue\r\n--$boundary--\r\n".toByteArray(Charsets.UTF_8)
        val c = connection(config, "/api/files/local", "POST")
        try {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            c.setFixedLengthStreamingMode(prefix.size.toLong() + file.length() + suffix.size)
            BufferedOutputStream(c.outputStream).use { out ->
                out.write(prefix)
                BufferedInputStream(file.inputStream()).use { it.copyTo(out, 64 * 1024) }
                out.write(suffix)
            }
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("Envoi refusé (HTTP $code) : ${body.take(200)}")
            return "$safeName envoyé et sélectionné dans OctoPrint. Tu peux lancer l'impression."
        } finally { c.disconnect() }
    }

}

private object PcBridgeApi {
    fun sendModel(context: Context, config: AppConfig, uri: Uri): String {
        require(config.pcUrl.startsWith("http://") || config.pcUrl.startsWith("https://")) {
            "Configure l'adresse du relais PC dans Réglages."
        }
        require(config.pcToken.isNotBlank()) { "Ajoute le jeton du relais PC dans Réglages." }
        val name = displayName(context, uri)
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        require(ext in setOf("3mf", "stl", "obj")) { "Choisis un modèle .3mf, .stl ou .obj." }
        val temp = File.createTempFile("orcaglass_model_", ".$ext", context.cacheDir)
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(temp).use { output -> input.copyTo(output) }
            } ?: throw IllegalStateException("Impossible de lire ce modèle.")
            require(temp.length() in 1..300_000_000L) { "Modèle vide ou trop volumineux (limite : 300 Mo)." }
            val encodedName = java.net.URLEncoder.encode(name, "UTF-8")
            val c = (URL(config.pcUrl.trimEnd('/') + "/open-model?name=$encodedName").openConnection() as HttpURLConnection)
            try {
                c.requestMethod = "PUT"
                c.connectTimeout = 7000
                c.readTimeout = 20000
                c.doOutput = true
                c.setRequestProperty("X-OrcaGlass-Token", config.pcToken)
                c.setRequestProperty("Content-Type", "application/octet-stream")
                c.setFixedLengthStreamingMode(temp.length())
                BufferedOutputStream(c.outputStream).use { out -> BufferedInputStream(temp.inputStream()).use { it.copyTo(out, 64 * 1024) } }
                val code = c.responseCode
                val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) throw IllegalStateException("Relais PC HTTP $code : ${body.take(180)}")
                return "Modèle envoyé au PC. OrcaSlicer doit s'ouvrir pour le tranchage."
            } finally { c.disconnect() }
        } finally { temp.delete() }
    }

    fun listGcodes(config: AppConfig): List<PcGcodeInfo> {
        val c = (URL(config.pcUrl.trimEnd('/') + "/gcode-files").openConnection() as HttpURLConnection)
        try {
            c.connectTimeout = 5000
            c.readTimeout = 7000
            c.setRequestProperty("X-OrcaGlass-Token", config.pcToken)
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("Relais PC HTTP $code : ${body.take(160)}")
            val array = JSONObject(body).optJSONArray("files") ?: org.json.JSONArray()
            return buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    add(PcGcodeInfo(item.optString("name"), item.optLong("size")))
                }
            }
        } finally { c.disconnect() }
    }

    fun downloadGcode(context: Context, config: AppConfig, name: String): File {
        val encoded = java.net.URLEncoder.encode(name, "UTF-8")
        val c = (URL(config.pcUrl.trimEnd('/') + "/gcode-file?name=$encoded").openConnection() as HttpURLConnection)
        val target = File.createTempFile("orcaglass_pc_", ".gcode", context.cacheDir)
        try {
            c.connectTimeout = 7000
            c.readTimeout = 30000
            c.setRequestProperty("X-OrcaGlass-Token", config.pcToken)
            val code = c.responseCode
            if (code !in 200..299) {
                val detail = c.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                throw IllegalStateException("Téléchargement PC HTTP $code : ${detail.take(160)}")
            }
            BufferedInputStream(c.inputStream).use { input -> FileOutputStream(target).use { output -> input.copyTo(output, 64 * 1024) } }
            require(target.length() in 1..400_000_000L) { "G-code PC vide ou trop volumineux." }
            return target
        } catch (e: Exception) {
            target.delete()
            throw e
        } finally { c.disconnect() }
    }
}

private data class PcGcodeInfo(val name: String, val size: Long)

private fun displayName(context: Context, uri: Uri): String {
    var name = "fichier"
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) name = cursor.getString(0) ?: name
    }
    return name
}

@Composable
private fun OrcaGlassApp() {
    val context = LocalContext.current
    val store = remember { ConfigStore(context) }
    var config by remember { mutableStateOf(store.read()) }
    var snapshot by remember { mutableStateOf(PrinterSnapshot()) }
    var activeTab by remember { mutableStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    var showStartConfirm by remember { mutableStateOf(false) }
    var showStopConfirm by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var toastMessage by remember { mutableStateOf("Connecte ton PC pour commencer.") }
    var selectedGcode by remember { mutableStateOf<Uri?>(null) }
    var selectedModel by remember { mutableStateOf<Uri?>(null) }
    var selectedGcodeName by remember { mutableStateOf("") }
    var selectedModelName by remember { mutableStateOf("") }
    var pcGcodeFiles by remember { mutableStateOf(emptyList<PcGcodeInfo>()) }
    val scope = rememberCoroutineScope()

    val gcodePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        selectedGcode = uri
        selectedGcodeName = uri?.let { displayName(context, it) }.orEmpty()
    }
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        selectedModel = uri
        selectedModelName = uri?.let { displayName(context, it) }.orEmpty()
    }

    LaunchedEffect(config.octoUrl, config.apiKey) {
        if (config.octoUrl.isNotBlank() && config.apiKey.isNotBlank()) {
            while (true) {
                try {
                    val fresh = withContext(Dispatchers.IO) { OctoPrintApi.snapshot(config) }
                    snapshot = fresh
                } catch (e: Exception) {
                    snapshot = PrinterSnapshot(connected = false, state = "Hors ligne", error = e.message ?: "Connexion impossible")
                }
                delay(2500)
            }
        } else {
            snapshot = PrinterSnapshot()
        }
    }

    fun perform(action: suspend () -> String) {
        scope.launch {
            busy = true
            try { toastMessage = withContext(Dispatchers.IO) { action() } }
            catch (e: Exception) { toastMessage = e.message ?: "Une erreur est survenue." }
            finally { busy = false }
        }
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Ink, Ink2, Ink)))) {
        AmbientGlow()
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 22.dp, end = 18.dp, top = 18.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Bolt, null, tint = Cyan, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.width(7.dp))
                        Text("ORCAGLASS", color = White, fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    }
                    Text("PRINT STUDIO  ·  ENDER SERIES", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                }
                Surface(
                    modifier = Modifier.size(43.dp).clickable { showSettings = true },
                    color = Glass,
                    shape = CircleShape,
                    border = BorderStroke(1.dp, GlassLight)
                ) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Settings, "Réglages", tint = White) }
                }
            }

            AnimatedContent(targetState = activeTab, label = "main-tabs", modifier = Modifier.weight(1f)) { tab ->
                when (tab) {
                    0 -> HomeScreen(
                        snapshot = snapshot,
                        busy = busy,
                        toastMessage = toastMessage,
                        onConnect = { showSettings = true },
                        onUpload = { activeTab = 2 },
                        onStart = { showStartConfirm = true },
                        onPauseResume = {
                            val act = if (snapshot.paused) "resume" else "pause"
                            perform { OctoPrintApi.command(config, JSONObject().put("command", "pause").put("action", act)); if (act == "pause") "Impression mise en pause." else "Reprise de l'impression demandée." }
                        },
                        onStop = { showStopConfirm = true }
                    )
                    1 -> MakerWorldScreen()
                    2 -> WorkshopScreen(
                        selectedGcodeName = selectedGcodeName,
                        selectedModelName = selectedModelName,
                        pcGcodeFiles = pcGcodeFiles,
                        pcReady = config.pcUrl.isNotBlank() && config.pcToken.isNotBlank(),
                        octoReady = config.octoUrl.isNotBlank() && config.apiKey.isNotBlank(),
                        busy = busy,
                        onPickGcode = { gcodePicker.launch(arrayOf("*/*")) },
                        onPickModel = { modelPicker.launch(arrayOf("*/*")) },
                        onSendGcode = {
                            val uri = selectedGcode
                            if (uri == null) toastMessage = "Choisis d'abord un fichier G-code."
                            else perform { OctoPrintApi.uploadGcode(context, config, uri) }
                        },
                        onSendModel = {
                            val uri = selectedModel
                            if (uri == null) toastMessage = "Choisis d'abord un modèle 3MF/STL."
                            else perform { PcBridgeApi.sendModel(context, config, uri) }
                        },
                        onRefreshPcFiles = {
                            scope.launch {
                                busy = true
                                try {
                                    pcGcodeFiles = withContext(Dispatchers.IO) { PcBridgeApi.listGcodes(config) }
                                    toastMessage = "${pcGcodeFiles.size} G-code(s) trouvé(s) dans le dossier Outbox du PC."
                                } catch (e: Exception) { toastMessage = e.message ?: "Impossible de lire le PC." }
                                finally { busy = false }
                            }
                        },
                        onSendPcGcode = { info ->
                            perform {
                                val file = PcBridgeApi.downloadGcode(context, config, info.name)
                                try { OctoPrintApi.uploadGcodeFile(config, file, info.name) }
                                finally { file.delete() }
                            }
                        },
                        onSettings = { showSettings = true }
                    )
                    else -> PrinterScreen(snapshot = snapshot, config = config, onSettings = { showSettings = true }, onRefresh = {
                        perform { val s = OctoPrintApi.snapshot(config); snapshot = s; "Statut actualisé : ${s.state}." }
                    })
                }
            }

            BottomBar(activeTab = activeTab, onSelect = { activeTab = it })
        }
    }

    if (showSettings) {
        SettingsDialog(config = config, onDismiss = { showSettings = false }, onSave = {
            config = it
            store.write(it)
            showSettings = false
            toastMessage = "Réglages enregistrés. Connexion en cours…"
        })
    }
    if (showStartConfirm) {
        ConfirmDialog(
            title = "Lancer l'impression ?",
            body = "Vérifie que le plateau est dégagé, que le G-code correspond à ton Ender 3 V2 et que l'imprimante est prête.",
            confirm = "Lancer",
            onDismiss = { showStartConfirm = false },
            onConfirm = {
                showStartConfirm = false
                perform { OctoPrintApi.command(config, JSONObject().put("command", "start")); "Ordre de démarrage envoyé à l'Ender 3 V2." }
            }
        )
    }
    if (showStopConfirm) {
        ConfirmDialog(
            title = "Arrêter l'impression ?",
            body = "L'impression en cours sera annulée. Cette action ne peut pas être annulée.",
            confirm = "Arrêter",
            danger = true,
            onDismiss = { showStopConfirm = false },
            onConfirm = {
                showStopConfirm = false
                perform { OctoPrintApi.command(config, JSONObject().put("command", "cancel")); "Annulation envoyée à l'imprimante." }
            }
        )
    }
}

@Composable
private fun AmbientGlow() {
    val transition = rememberInfiniteTransition(label = "ambient")
    val alpha by transition.animateFloat(
        initialValue = 0.12f, targetValue = 0.25f,
        animationSpec = infiniteRepeatable(tween(4600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow-alpha"
    )
    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier.align(Alignment.TopEnd).padding(top = 70.dp, end = 5.dp).size(190.dp)
                .graphicsLayer { this.alpha = alpha }
                .background(Brush.radialGradient(listOf(Blue.copy(alpha = 0.7f), Color.Transparent)), CircleShape)
        )
        Box(
            Modifier.align(Alignment.BottomStart).padding(bottom = 65.dp, start = 0.dp).size(210.dp)
                .graphicsLayer { this.alpha = alpha * 0.75f }
                .background(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.55f), Color.Transparent)), CircleShape)
        )
    }
}

@Composable
private fun GlassCard(modifier: Modifier = Modifier, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Column(
        modifier
            .shadow(18.dp, RoundedCornerShape(25.dp), ambientColor = Color.Black.copy(alpha = 0.18f))
            .clip(RoundedCornerShape(25.dp))
            .background(Brush.linearGradient(listOf(Color(0xC225344A), Color(0x9C151F30), Color(0xB51D2A3C))))
            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = 0.26f), Color.White.copy(alpha = 0.05f))), RoundedCornerShape(25.dp))
            .padding(17.dp),
        content = content
    )
}

@Composable
private fun HomeScreen(
    snapshot: PrinterSnapshot,
    busy: Boolean,
    toastMessage: String,
    onConnect: () -> Unit,
    onUpload: () -> Unit,
    onStart: () -> Unit,
    onPauseResume: () -> Unit,
    onStop: () -> Unit
) {
    val scroll = rememberScrollState()
    Column(Modifier.fillMaxSize().verticalScroll(scroll).padding(horizontal = 18.dp).padding(bottom = 12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("Ton atelier,", color = White, fontSize = 27.sp, fontWeight = FontWeight.SemiBold)
                Text("à portée de main.", color = Cyan, fontSize = 27.sp, fontWeight = FontWeight.SemiBold)
            }
            PrinterOrb(online = snapshot.connected)
        }
        Spacer(Modifier.height(18.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("ENDER 3 V2", color = White, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp, fontSize = 14.sp)
                    Spacer(Modifier.height(5.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).background(if (snapshot.connected) Mint else Danger, CircleShape))
                        Spacer(Modifier.width(7.dp))
                        Text(if (snapshot.connected) snapshot.state else "Déconnectée", color = if (snapshot.connected) Mint else Muted, fontSize = 12.sp)
                    }
                }
                Surface(color = Color(0x263AC8A4), shape = RoundedCornerShape(12.dp)) {
                    Text(if (snapshot.connected) "USB · PC" else "WIFI · PC", color = if (snapshot.connected) Mint else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp))
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TemperatureTile(Modifier.weight(1f), "BUSE", snapshot.toolActual, snapshot.toolTarget, Icons.Rounded.LocalFireDepartment)
                TemperatureTile(Modifier.weight(1f), "PLATEAU", snapshot.bedActual, snapshot.bedTarget, Icons.Rounded.Thermostat)
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Imprimante", color = Muted, fontSize = 11.sp)
                Text(if (snapshot.connected) "Synchronisation active" else "Configure OctoPrint", color = Muted, fontSize = 10.sp)
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Wifi, null, tint = if (snapshot.connected) Mint else Muted, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(7.dp))
                Text(if (snapshot.connected) "PC connecté · actualisation 2,5 s" else "Téléphone → Wi-Fi → PC → USB → Ender 3 V2", color = Muted, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Impression en cours", color = White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text("${snapshot.progress?.toInt() ?: 0}%", color = Cyan, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(7.dp))
            Text(snapshot.fileName, color = Muted, fontSize = 11.sp, maxLines = 1)
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = ((snapshot.progress ?: 0.0).coerceIn(0.0, 100.0) / 100.0).toFloat(),
                modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                color = Cyan,
                trackColor = Color.White.copy(alpha = 0.10f)
            )
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(if (snapshot.printing || snapshot.paused) "${snapshot.state}" else "Prêt pour le prochain projet", color = Muted, fontSize = 10.sp)
                Text(snapshot.remainingSeconds?.let { "~${formatDuration(it)}" } ?: "", color = Muted, fontSize = 10.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionButton(Modifier.weight(1.2f), "Atelier", Icons.Rounded.FolderOpen, enabled = !busy, onClick = onUpload)
            ActionButton(Modifier.weight(1f), if (snapshot.paused) "Reprendre" else "Pause", if (snapshot.paused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause, enabled = snapshot.connected && (snapshot.printing || snapshot.paused) && !busy, onClick = onPauseResume)
            ActionButton(Modifier.weight(0.75f), "Stop", Icons.Rounded.Stop, enabled = snapshot.connected && (snapshot.printing || snapshot.paused) && !busy, danger = true, onClick = onStop)
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = onStart,
            enabled = snapshot.connected && snapshot.ready && !snapshot.printing && !snapshot.paused && !busy,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Ink, disabledContainerColor = Color(0xFF29384B), disabledContentColor = Muted)
        ) {
            if (busy) CircularProgressIndicator(Modifier.size(18.dp), color = Ink, strokeWidth = 2.dp)
            else Icon(Icons.Rounded.PlayArrow, null)
            Spacer(Modifier.width(7.dp))
            Text("LANCER L'IMPRESSION", fontWeight = FontWeight.ExtraBold, letterSpacing = 0.8.sp)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.04f)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.CheckCircle, null, tint = if (snapshot.connected) Mint else Muted, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text(toastMessage, color = Muted, fontSize = 11.sp, maxLines = 2)
        }
        if (!snapshot.connected && snapshot.error != null) {
            Spacer(Modifier.height(8.dp))
            Text(snapshot.error, color = Danger, fontSize = 10.sp)
            TextButtonLike("Configurer la connexion", onConnect)
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun PrinterOrb(online: Boolean) {
    val transition = rememberInfiniteTransition(label = "printer-orb")
    val scale by transition.animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(2100), RepeatMode.Reverse), label = "orb-scale")
    Box(Modifier.size(72.dp).graphicsLayer { scaleX = scale; scaleY = scale }.background(Brush.radialGradient(listOf((if (online) Cyan else Blue).copy(alpha = 0.32f), Color.Transparent)), CircleShape), contentAlignment = Alignment.Center) {
        Box(Modifier.size(50.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF263B56), Color(0xFF111C2B)))).border(1.dp, Color.White.copy(alpha = 0.18f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Print, null, tint = if (online) Cyan else Muted, modifier = Modifier.size(25.dp))
        }
    }
}

@Composable
private fun TemperatureTile(modifier: Modifier, title: String, actual: Double?, target: Double?, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(modifier.clip(RoundedCornerShape(17.dp)).background(Color.White.copy(alpha = 0.045f)).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(5.dp))
            Text(title, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(actual?.let { "${it.toInt()}" } ?: "—", color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("°C", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(start = 3.dp, bottom = 4.dp))
        }
        Text("Cible : ${target?.let { "${it.toInt()}°" } ?: "—"}", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun ActionButton(modifier: Modifier, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, enabled: Boolean, danger: Boolean = false, onClick: () -> Unit) {
    val scale by animateFloatAsState(if (enabled) 1f else 0.98f, animationSpec = spring(), label = "action-scale")
    Column(
        modifier.graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(16.dp))
            .background(if (danger) Color(0x22FF7788) else Glass)
            .border(1.dp, if (danger) Danger.copy(alpha = 0.22f) else GlassLight, RoundedCornerShape(16.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = if (danger) Danger else if (enabled) Cyan else Muted, modifier = Modifier.size(19.dp))
        Spacer(Modifier.height(5.dp))
        Text(label, color = if (enabled) White else Muted, fontSize = 9.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun MakerWorldLoadingOverlay(visible: Boolean) {
    // Kept in a separate composable so the non-ColumnScope AnimatedVisibility
    // overload is selected even when MakerWorldScreen is called from a Column.
    AnimatedVisibility(
        visible = visible,
        modifier = Modifier.fillMaxSize()
    ) {
        Box(
            Modifier.fillMaxSize().background(Color(0xE6101724)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = Cyan)
                Spacer(Modifier.height(12.dp))
                Text("Ouverture du catalogue…", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun MakerWorldScreen() {
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Explore, null, tint = Cyan)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text("MakerWorld", color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("Catalogue officiel · modèles 3D", color = Muted, fontSize = 10.sp)
                }
                Surface(color = Color(0x263BD7A6), shape = RoundedCornerShape(9.dp)) {
                    Text("EN LIGNE", color = Mint, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.weight(1f).clip(RoundedCornerShape(22.dp)).background(Color(0xFF111722)).border(1.dp, GlassLight, RoundedCornerShape(22.dp))) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.loadsImagesAutomatically = true
                        settings.javaScriptCanOpenWindowsAutomatically = false
                        CookieManager.getInstance().setAcceptCookie(true)
                        webViewClient = object : WebViewClient() {
                            override fun onPageFinished(view: WebView?, url: String?) { loading = false; error = false }
                            override fun onReceivedError(view: WebView?, request: android.webkit.WebResourceRequest?, e: android.webkit.WebResourceError?) {
                                if (request?.isForMainFrame == true) { loading = false; error = true }
                            }
                        }
                        webChromeClient = WebChromeClient()
                        setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                            try {
                                val request = DownloadManager.Request(Uri.parse(url))
                                    .setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
                                    .setDescription("Téléchargement MakerWorld")
                                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType))
                                    .setAllowedOverMetered(true)
                                    .setAllowedOverRoaming(false)
                                CookieManager.getInstance().getCookie(url)?.let { request.addRequestHeader("Cookie", it) }
                                if (!userAgent.isNullOrBlank()) request.addRequestHeader("User-Agent", userAgent)
                                (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                            } catch (_: Exception) { error = true }
                        }
                        loadUrl("https://makerworld.com/fr")
                    }
                },
                update = { }
            )
            MakerWorldLoadingOverlay(visible = loading)
            if (error) {
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xE61A2434)).padding(12.dp)) {
                    Text("Le catalogue n'a pas répondu. Vérifie ta connexion ou ouvre MakerWorld dans Chrome.", color = White, fontSize = 11.sp)
                }
            }
        }
        Text("Télécharge un fichier 3MF/STL, puis va dans Atelier pour l'envoyer à OrcaSlicer sur ton PC.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(vertical = 9.dp, horizontal = 4.dp))
    }
}

@Composable
private fun WorkshopScreen(
    selectedGcodeName: String,
    selectedModelName: String,
    pcGcodeFiles: List<PcGcodeInfo>,
    pcReady: Boolean,
    octoReady: Boolean,
    busy: Boolean,
    onPickGcode: () -> Unit,
    onPickModel: () -> Unit,
    onSendGcode: () -> Unit,
    onSendModel: () -> Unit,
    onRefreshPcFiles: () -> Unit,
    onSendPcGcode: (PcGcodeInfo) -> Unit,
    onSettings: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        Text("Atelier", color = White, fontSize = 27.sp, fontWeight = FontWeight.SemiBold)
        Text("Du modèle au premier filament.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(18.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.FolderOpen, null, tint = Cyan, modifier = Modifier.size(23.dp))
                Spacer(Modifier.width(9.dp))
                Column {
                    Text("1 · Modèle MakerWorld", color = White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text("3MF · STL · OBJ → OrcaSlicer sur PC", color = Muted, fontSize = 10.sp)
                }
            }
            Spacer(Modifier.height(15.dp))
            Button(onClick = onPickModel, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF283B56))) {
                Icon(Icons.Rounded.FolderOpen, null, tint = Cyan)
                Spacer(Modifier.width(8.dp))
                Text(if (selectedModelName.isBlank()) "Choisir un modèle 3D" else selectedModelName, color = White, maxLines = 1)
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onSendModel, enabled = selectedModelName.isNotBlank() && pcReady && !busy, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Ink, disabledContainerColor = Color(0xFF29384B), disabledContentColor = Muted)) {
                if (busy) CircularProgressIndicator(Modifier.size(17.dp), color = Ink, strokeWidth = 2.dp) else Icon(Icons.Rounded.Bolt, null)
                Spacer(Modifier.width(7.dp))
                Text("ENVOYER À ORCASLICER", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(7.dp))
            Text(if (pcReady) "Relais PC configuré" else "Relais PC non configuré · Réglages", color = if (pcReady) Mint else Muted, fontSize = 10.sp)
        }
        Spacer(Modifier.height(13.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.CloudUpload, null, tint = Cyan, modifier = Modifier.size(23.dp))
                Spacer(Modifier.width(9.dp))
                Column {
                    Text("2 · Envoyer le G-code", color = White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text("Après le tranchage dans OrcaSlicer", color = Muted, fontSize = 10.sp)
                }
            }
            Spacer(Modifier.height(15.dp))
            Button(onClick = onPickGcode, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF283B56))) {
                Icon(Icons.Rounded.FolderOpen, null, tint = Cyan)
                Spacer(Modifier.width(8.dp))
                Text(if (selectedGcodeName.isBlank()) "Choisir un fichier .gcode" else selectedGcodeName, color = White, maxLines = 1)
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onSendGcode, enabled = selectedGcodeName.isNotBlank() && octoReady && !busy, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Ink, disabledContainerColor = Color(0xFF29384B), disabledContentColor = Muted)) {
                if (busy) CircularProgressIndicator(Modifier.size(17.dp), color = Ink, strokeWidth = 2.dp) else Icon(Icons.Rounded.CloudUpload, null)
                Spacer(Modifier.width(7.dp))
                Text("ENVOYER À L'IMPRIMANTE", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(7.dp))
            Text(if (octoReady) "OctoPrint configuré · impression à confirmer dans Accueil" else "OctoPrint non configuré · Réglages", color = if (octoReady) Mint else Muted, fontSize = 10.sp)
        }
        Spacer(Modifier.height(13.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("3 · G-code exportés sur le PC", color = White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text("Dossier OrcaGlass/Outbox", color = Muted, fontSize = 10.sp)
                }
                TextButton(onClick = onRefreshPcFiles, enabled = pcReady && !busy) { Text("Actualiser", color = Cyan, fontSize = 11.sp) }
            }
            Spacer(Modifier.height(7.dp))
            if (pcGcodeFiles.isEmpty()) {
                Text("Exporte le G-code depuis OrcaSlicer vers le dossier Outbox du PC, puis actualise ici.", color = Muted, fontSize = 10.sp)
            } else {
                pcGcodeFiles.forEach { info ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(info.name, color = White, fontSize = 11.sp, maxLines = 1)
                            Text("${(info.size / 1024.0 / 1024.0).let { String.format(Locale.FRANCE, "%.1f Mo", it) }}", color = Muted, fontSize = 9.sp)
                        }
                        TextButton(onClick = { onSendPcGcode(info) }, enabled = octoReady && !busy) { Text("Envoyer", color = Cyan, fontSize = 10.sp) }
                    }
                }
            }
        }
        Spacer(Modifier.height(13.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Text("Le parcours", color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            WorkflowStep("01", "MakerWorld", "Télécharge ton modèle 3D")
            WorkflowStep("02", "OrcaSlicer sur PC", "Choisis le profil Ender 3 V2 et tranche")
            WorkflowStep("03", "OrcaGlass + OctoPrint", "Envoie le .gcode par Wi-Fi puis lance")
        }
        TextButtonLike("Configurer les connexions", onSettings)
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun WorkflowStep(number: String, title: String, subtitle: String) {
    Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(31.dp).clip(CircleShape).background(Color(0x263FCDEB)), contentAlignment = Alignment.Center) {
            Text(number, color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(11.dp))
        Column {
            Text(title, color = White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun PrinterScreen(snapshot: PrinterSnapshot, config: AppConfig, onSettings: () -> Unit, onRefresh: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Imprimante", color = White, fontSize = 27.sp, fontWeight = FontWeight.SemiBold)
                Text("Supervision en temps réel", color = Muted, fontSize = 12.sp)
            }
            Surface(Modifier.size(42.dp).clickable { onRefresh() }, color = Glass, shape = CircleShape, border = BorderStroke(1.dp, GlassLight)) {
                Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Refresh, "Actualiser", tint = Cyan) }
            }
        }
        Spacer(Modifier.height(16.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Print, null, tint = Cyan, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Creality Ender 3 V2", color = White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(if (snapshot.connected) snapshot.state else "En attente de connexion", color = if (snapshot.connected) Mint else Danger, fontSize = 11.sp)
                }
                Box(Modifier.size(9.dp).background(if (snapshot.connected) Mint else Danger, CircleShape))
            }
            Spacer(Modifier.height(18.dp))
            DetailRow("Buse", snapshot.toolActual, snapshot.toolTarget)
            Spacer(Modifier.height(12.dp))
            DetailRow("Plateau", snapshot.bedActual, snapshot.bedTarget)
            Spacer(Modifier.height(12.dp))
            DetailRow("Progression", snapshot.progress, null, percent = true)
            Spacer(Modifier.height(12.dp))
            DetailRow("Temps restant", snapshot.remainingSeconds?.toDouble(), null, duration = true)
        }
        Spacer(Modifier.height(14.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Text("Connexion", color = White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(9.dp))
            ConnectionLine("OctoPrint", if (config.octoUrl.isBlank()) "Non configuré" else config.octoUrl, config.octoUrl.isNotBlank())
            Spacer(Modifier.height(7.dp))
            ConnectionLine("Relais OrcaGlass PC", if (config.pcUrl.isBlank()) "Optionnel · non configuré" else config.pcUrl, config.pcUrl.isNotBlank())
            Spacer(Modifier.height(7.dp))
            ConnectionLine("Imprimante", "USB relié au PC", true)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onSettings, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2B3E58))) {
                Icon(Icons.Rounded.Settings, null, tint = Cyan)
                Spacer(Modifier.width(7.dp))
                Text("Paramètres de connexion", color = White)
            }
        }
        Spacer(Modifier.height(15.dp))
    }
}

@Composable
private fun DetailRow(label: String, value: Double?, target: Double?, percent: Boolean = false, duration: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 12.sp)
        val text = when {
            duration -> value?.let { formatDuration(it.toInt()) } ?: "—"
            value == null -> "—"
            percent -> "${value.toInt()} %"
            else -> "${value.toInt()}°C" + (target?.let { " / ${it.toInt()}°" } ?: "")
        }
        Text(text, color = White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ConnectionLine(name: String, value: String, configured: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(name, color = Muted, fontSize = 11.sp)
        Text(value, color = if (configured) Mint else Muted, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun BottomBar(activeTab: Int, onSelect: (Int) -> Unit) {
    val items = listOf(
        Triple("Accueil", Icons.Rounded.Home, 0),
        Triple("MakerWorld", Icons.Rounded.Explore, 1),
        Triple("Atelier", Icons.Rounded.FolderOpen, 2),
        Triple("Machine", Icons.Rounded.Print, 3)
    )
    Row(
        Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, top = 7.dp, bottom = 8.dp)
            .clip(RoundedCornerShape(23.dp))
            .background(Brush.verticalGradient(listOf(Color(0xE72B394D), Color(0xE9152030))))
            .border(1.dp, Color.White.copy(alpha = 0.11f), RoundedCornerShape(23.dp))
            .padding(horizontal = 5.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        items.forEach { (label, icon, index) ->
            val selected = activeTab == index
            val scale by animateFloatAsState(if (selected) 1.05f else 1f, label = "nav-scale-$index")
            Column(
                Modifier.weight(1f).graphicsLayer { scaleX = scale; scaleY = scale }
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onSelect(index) }
                    .background(if (selected) Color.White.copy(alpha = 0.09f) else Color.Transparent)
                    .padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(icon, null, tint = if (selected) Cyan else Muted, modifier = Modifier.size(20.dp))
                Spacer(Modifier.height(3.dp))
                Text(label, color = if (selected) White else Muted, fontSize = 9.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
            }
        }
    }
}

@Composable
private fun SettingsDialog(config: AppConfig, onDismiss: () -> Unit, onSave: (AppConfig) -> Unit) {
    var octoUrl by remember(config) { mutableStateOf(config.octoUrl) }
    var apiKey by remember(config) { mutableStateOf(config.apiKey) }
    var pcUrl by remember(config) { mutableStateOf(config.pcUrl) }
    var pcToken by remember(config) { mutableStateOf(config.pcToken) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF182437),
        titleContentColor = White,
        textContentColor = Muted,
        title = { Text("Connexions", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("OCTOPRINT · USB → WIFI", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                DarkField(octoUrl, { octoUrl = it }, "URL OctoPrint", "http://192.168.1.20:5000")
                DarkField(apiKey, { apiKey = it }, "Clé API OctoPrint", "Clé depuis OctoPrint", secret = true)
                Spacer(Modifier.height(3.dp))
                Text("RELAIS PC · MODÈLES VERS ORCASLICER", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                DarkField(pcUrl, { pcUrl = it }, "URL relais PC", "http://192.168.1.20:8765")
                DarkField(pcToken, { pcToken = it }, "Jeton relais PC", "À copier depuis la fenêtre PC", secret = true)
                Text("Le téléphone et le PC doivent être sur le même Wi-Fi. N'expose pas ces adresses sur Internet.", color = Muted, fontSize = 10.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(AppConfig(octoUrl, apiKey, pcUrl, pcToken)) }) { Text("Enregistrer", color = Cyan, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler", color = Muted) } }
    )
}

@Composable
private fun DarkField(value: String, onValue: (String) -> Unit, label: String, placeholder: String, secret: Boolean = false) {
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label, fontSize = 11.sp) },
        placeholder = { Text(placeholder, fontSize = 10.sp) },
        singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = White,
            unfocusedTextColor = White,
            focusedBorderColor = Cyan,
            unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
            focusedLabelColor = Cyan,
            unfocusedLabelColor = Muted,
            cursorColor = Cyan
        )
    )
}

@Composable
private fun ConfirmDialog(title: String, body: String, confirm: String, danger: Boolean = false, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF182437),
        title = { Text(title, color = White, fontWeight = FontWeight.Bold) },
        text = { Text(body, color = Muted, fontSize = 12.sp) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm, color = if (danger) Danger else Cyan, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler", color = Muted) } }
    )
}

@Composable
private fun TextButtonLike(label: String, onClick: () -> Unit) {
    Text(label, color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp).clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(5.dp))
}

private fun formatDuration(seconds: Int): String {
    val safe = seconds.coerceAtLeast(0)
    val hours = safe / 3600
    val minutes = (safe % 3600) / 60
    return if (hours > 0) "${hours} h ${minutes} min" else "$minutes min"
}
